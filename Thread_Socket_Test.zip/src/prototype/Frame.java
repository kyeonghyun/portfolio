package prototype;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class Frame extends JFrame {
	public Frame() {

		setTitle("ProtoType");

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Container contentPane = getContentPane();

		contentPane.setLayout(null);

		JTextArea txta1 = new JTextArea();
		JScrollPane scroll1 = new JScrollPane(txta1);
		scroll1.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scroll1.setBounds(190, 60, 300, 100);
		contentPane.add(scroll1);

		JButton btn_selP = new JButton("ȸ������");
		btn_selP.setLocation(40, 60);
		btn_selP.setSize(120, 80);
		contentPane.add(btn_selP);

		btn_selP.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				txta1.setText("");
//				Rasp_socket mP = new Rasp_socket();
//				mP.loadRasp_socket(txta1);
			}
		});

		JButton btn_clr = new JButton("�� �����");
		btn_clr.setLocation(660, 60);
		btn_clr.setSize(100, 200);
		contentPane.add(btn_clr);
		btn_clr.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				txta1.setText("");

			}
		});

		JButton btn_exit = new JButton("����");
		btn_exit.setLocation(660, 300);
		btn_exit.setSize(100, 200);
		contentPane.add(btn_exit);
		btn_exit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});

		setSize(800, 600);
		setVisible(true);

	}

}
