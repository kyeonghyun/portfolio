package com.example.testapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.TestLooperManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    final String ID = "1234";
    final String PW = "5678";
    final String PN = "1111";
    final String J_PW1="2222";
    final String J_PW2="2222";
    final String SN="serial1";

    static String SS1 = "";
    static String SS2 = "";
    static String SS3 = "";
    static String SS4 = "";
    static String SS5 = "";
    static String SS6 = "";
    static String SS7 = "";
    static String SS8 = "";
    static String SS9 = "";
//    static String rasp="";

    final int TIME=5;
    final int SUB=5;

    final int SUBN=5;

    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = (TextView) findViewById(R.id.textview);
        Button loginbtn = (Button) findViewById(R.id.loginbtn);
        Button joinbtn = (Button) findViewById(R.id.joinbtn);
        Button schedulebtn = (Button) findViewById(R.id.schedulebtn);
        Button todaybyn = (Button) findViewById(R.id.todaybtn);

        SocketThread m1 = SocketThread.get();
        m1.connect();
        Log.d("TEST", "연결됨");


        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("TEST", "버튼눌림");
                DBManager m2 = DBManager.getInstance();
                m2.setOutput(ID, PW);
                textView.append("id: " + SS1 + "\n");
                textView.append(" pw: " + SS2 + "\n");

            }
        });
        joinbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DBManager m = DBManager.getInstance();
                m.setjoin(PN, J_PW1, J_PW2, SN);
                textView.append("PN: " + SS3 + "\n");
                textView.append("J_PW1: " + SS4 + "\n");
                textView.append("J_PW2: " + SS5 + "\n");
                textView.append("SN: " + SS6 + "\n");

            }
        });
        schedulebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DBManager m = DBManager.getInstance();
                m.setschedule(TIME, SUB);
                textView.append("TIME: " + SS7 + "\n");
                textView.append("SUB: " + SS8 + "\n");
            }
        });
        todaybyn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DBManager m = DBManager.getInstance();
                m.setToday(SUBN);
                textView.append("SUBN: " + SS9 + "\n");
            }
        });


//        DBManager m = DBManager.getInstance();
//        m.setRasp();
//
//        if (rasp != "") {
//            textView.append("라즈: " + rasp + "\n");
//        }

    }

}
