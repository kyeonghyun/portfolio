package com.example.testapp;

import android.os.Handler;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.Socket;


public class DBManager {
    static DBManager dbManager;
    private Handler handler;
    static Socket socket = null;
    static String ID = "";
    static String PW = "";

    static String PN = "";
    static String J_PW1="";
    static String J_PW2="";
    static String SN="";

    static int TIME=0;
    static int SUB=0;

    static int SUBN=0;



    private DBManager() {

    }

    public static DBManager getInstance() {

        if (dbManager == null)
            dbManager = new DBManager();
        return dbManager;
    }


    void setOutput(String ID, String PW) {
        DBManager.ID=ID;
        DBManager.PW=PW;
        Login mlogin = new Login();
        Log.w("로그", "버튼이 눌려짐");
        mlogin.start();
    }

    void setjoin(String PN, String J_PW1,String J_PW2, String SN) {
        DBManager.PN = PN;
        DBManager.J_PW1 = J_PW1;
        DBManager.J_PW2 = J_PW2;
        DBManager.SN = SN;
        join mjoin = new join();
        Log.w("로그", "버튼이 눌려짐");
        mjoin.start();
    }
    void setschedule(int TIME,int SUB){
        DBManager.TIME=TIME;
        DBManager.SUB=SUB;
        Schedule mschedule = new Schedule();
        mschedule.start();
    }
    void setToday(int SUBN){
        DBManager.SUBN=SUBN;
        Today mtoday=new Today();
        mtoday.start();
    }
//    void setRasp(){
//        Rasp r=new Rasp();
//        r.start();
//    }

}

class Login extends Thread {
    SocketThread mSocketThread = SocketThread.get(); // 추가된 구문
    String readData = null;

    @Override
    public void run() {
        super.run();


        try {
            Log.w("로그", "아이디 판별 진입");

            mSocketThread.write("1");

            InputStream in1 = SocketThread.socket.getInputStream();
            BufferedReader br1 = new BufferedReader(new InputStreamReader(in1));
            String echoID = br1.readLine();
            Log.d("TEST", ""+echoID);


            mSocketThread.write(DBManager.ID);
            InputStream in2 = SocketThread.socket.getInputStream();
            BufferedReader br2 = new BufferedReader(new InputStreamReader(in2));
            String echoID2 = br2.readLine();
            Log.d("TEST", "id: "+echoID2);

            mSocketThread.write(DBManager.PW);
            InputStream in3 = SocketThread.socket.getInputStream();
            BufferedReader br3 = new BufferedReader(new InputStreamReader(in3));
            String echoID3 = br3.readLine();
            Log.d("TEST", "pw: "+echoID3);
            MainActivity.SS1=echoID2;
            MainActivity.SS2=echoID3;


        } catch (Exception e) {
            e.printStackTrace();
            Log.w("로그 버퍼", "버퍼생성 잘못됨");
        }
        Log.w("로그 버퍼", "버퍼생성 잘됨");
    }
}
class join extends Thread{
    SocketThread mSocketThread = SocketThread.get(); // 추가된 구문
    String readData = null;

    @Override
    public void run() {
        super.run();

//        MainActivity main=new MainActivity();


        try{
            mSocketThread.write("2"); //보내는거거
            InputStream in1 = SocketThread.socket.getInputStream();
            BufferedReader br1 = new BufferedReader(new InputStreamReader(in1));
            String echoID = br1.readLine();
            Log.d("TEST", ""+echoID);
//            main.textView.append("핸드폰번호 : "+echoID);

            mSocketThread.write(DBManager.PN);
            InputStream in2 = SocketThread.socket.getInputStream();
            BufferedReader br2 = new BufferedReader(new InputStreamReader(in2));
            String echoID2 = br2.readLine();

            Log.d("TEST", ""+echoID2);


            mSocketThread.write(DBManager.J_PW1);
            InputStream in3 = SocketThread.socket.getInputStream();
            BufferedReader br3 = new BufferedReader(new InputStreamReader(in3));
            String echoID3 = br3.readLine();
            Log.d("TEST", ""+echoID3);

            mSocketThread.write(DBManager.J_PW2);
            InputStream in4 = SocketThread.socket.getInputStream();
            BufferedReader br4 = new BufferedReader(new InputStreamReader(in4));
            String echoID4 = br4.readLine();
            Log.d("TEST", ""+echoID4);

            mSocketThread.write(DBManager.SN);
            InputStream in5 = SocketThread.socket.getInputStream();
            BufferedReader br5 = new BufferedReader(new InputStreamReader(in5));
            String echoID5 = br5.readLine();
            Log.d("TEST", ""+echoID5);
            MainActivity.SS3=echoID2;
            MainActivity.SS4=echoID3;
            MainActivity.SS5=echoID4;
            MainActivity.SS6=echoID5;


        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
class Schedule extends Thread{
    SocketThread mSocketThread = SocketThread.get(); // 추가된 구문
    String readData = null;
    @Override
    public void run() {
        super.run();
        try {
            mSocketThread.write("3"); //보내는거거
            InputStream in1 = SocketThread.socket.getInputStream();
            BufferedReader br1 = new BufferedReader(new InputStreamReader(in1));
            String echoID = br1.readLine();
            Log.d("TEST", ""+echoID);

            mSocketThread.write2(DBManager.TIME);
            InputStream in2 = SocketThread.socket.getInputStream();
            BufferedReader br2 = new BufferedReader(new InputStreamReader(in2));
            String echoID2 = br2.readLine();
            Log.d("TEST", ""+echoID2);


            mSocketThread.write2(DBManager.SUB);
            InputStream in3 = SocketThread.socket.getInputStream();
            BufferedReader br3 = new BufferedReader(new InputStreamReader(in3));
            String echoID3 = br3.readLine();
            Log.d("TEST", ""+echoID3);
            MainActivity.SS7=echoID2;
            MainActivity.SS8=echoID3;

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
class Today extends Thread{
    SocketThread mSocketThread = SocketThread.get(); // 추가된 구문
    String readData = null;

    @Override
    public void run() {
        super.run();
        try{
            mSocketThread.write("4"); //보내는거거
            InputStream in1 = SocketThread.socket.getInputStream();
            BufferedReader br1 = new BufferedReader(new InputStreamReader(in1));
            String echoID = br1.readLine();
            Log.d("TEST", ""+echoID);

            mSocketThread.write2(DBManager.SUBN);
            InputStream in2 = SocketThread.socket.getInputStream();
            BufferedReader br2 = new BufferedReader(new InputStreamReader(in2));
            String echoID2 = br2.readLine();
            Log.d("TEST", ""+echoID2);
            MainActivity.SS9=echoID2;



        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

//class Rasp extends Thread{
//    SocketThread mSocketThread = SocketThread.get(); // 추가된 구문
//    String readData = null;
//
//    @Override
//    public void run() {
//        super.run();
//
//        try{
//            InputStream in2 = SocketThread.socket.getInputStream();
//            BufferedReader br2 = new BufferedReader(new InputStreamReader(in2));
//            String echoID2 = br2.readLine();
//
//            MainActivity.rasp=echoID2;
//            Log.d("TEST",""+MainActivity.rasp);
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
//}