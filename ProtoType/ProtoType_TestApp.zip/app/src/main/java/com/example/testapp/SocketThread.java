package com.example.testapp;

import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;

class SocketThread{
    static SocketThread m=null;
    static Socket socket=null;
    boolean isInterrupt = false;
    ArrayList<String> mRead_Queue = new ArrayList<String>();

    private SocketThread(){

    }
    static SocketThread get(){
        if(m == null)
            m= new SocketThread();
        return m;
    }

    String readData(){
        String msg =null;
        if(mRead_Queue.size() > 0)
        {
            msg = mRead_Queue.get(0);
            mRead_Queue.remove(0);
        }
        return msg;
    }

    void readThreadStart(){
        SocetThread_Read mRead = new SocetThread_Read();
        mRead.start();
    }

    void write(String msg){
        try{
            Log.w("로그", "Write 쓰레드 함수 진입");
            OutputStream out = socket.getOutputStream();
            PrintWriter pw = new PrintWriter(out, true);
            pw.println(msg);
            Log.w("로그", ""+msg);
            pw.flush();
        }catch(Exception e)
        {

        }
    }

    void write2(int msg){
        try{
            Log.w("로그", "Write 쓰레드 함수 진입");
            OutputStream out = socket.getOutputStream();
            PrintWriter pw = new PrintWriter(out, true);
            pw.println(msg);
            Log.w("로그", ""+msg);
            pw.flush();
        }catch(Exception e)
        {

        }
    }

    void connect() {
        {
            Join_Server m = new Join_Server();
            m.start();
        }

    }

}

class SocetThread_Read extends Thread{

    @Override
    public void run() {
        // TODO Auto-generated method stub
        super.run();
        try{
            SocketThread mSocketThread = SocketThread.get();
            InputStream in = mSocketThread.socket.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            while(!mSocketThread.isInterrupt)
            {
                String readMsg = br.readLine();
                mSocketThread.mRead_Queue.add(readMsg);
                Log.w("로그", "queue add : " + readMsg);
                Thread.sleep(100);
            }

        }catch(Exception e)
        {

        }
    }
}

class Join_Server extends Thread {
    @Override
    public void run() {
        super.run();

        String ip = "192.168.43.25";            // IP 번호
        int port = 5678;
        try {
            SocketThread.socket = new Socket(ip, port);
            Log.w("로그 서버 접속됨", "서버 접속됨");
        } catch (IOException e1) {
            Log.w("로그 서버접속못함", "서버접속못함");
            e1.printStackTrace();
        }
    }
}


