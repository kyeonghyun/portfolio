class And_Server extends Thread {
	
}