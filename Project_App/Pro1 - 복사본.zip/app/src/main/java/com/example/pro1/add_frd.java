package com.example.pro1;

import android.app.Activity;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.pro1.R.layout;

public class add_frd extends Activity {

    private DatabaseHelper dbhelper;
    private SQLiteDatabase db;
    String s_date,s_phonenum,s_name;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(layout.add_frd);

        final EditText phonenum=(EditText)findViewById(R.id.phonenum);
        final EditText name=(EditText)findViewById(R.id.name);
        Button savebtn=(Button)findViewById(R.id.savebtn);


        dbhelper=new DatabaseHelper(this);
        try{
            db=dbhelper.getReadableDatabase();
        }catch(SQLiteException e){
            db=dbhelper.getWritableDatabase();
        }


        savebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                s_name=name.getText().toString();
                s_phonenum=phonenum.getText().toString();

                db.execSQL("insert into schedule values(s_date,'"+s_phonenum+"',"+"'"+s_name+"');");
                Toast.makeText(add_frd.this,"추가되었습니다.",Toast.LENGTH_SHORT).show();
                phonenum.setText("");
                name.setText("");
            }
        });








    }
}
